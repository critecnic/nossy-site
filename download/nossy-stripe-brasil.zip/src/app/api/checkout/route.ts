import { NextResponse } from 'next/server';

const STRIPE_SECRET = process.env.STRIPE_SECRET_KEY || '';
const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL || 'https://nossy.pro';

const CURRENCY = process.env.STRIPE_CURRENCY || 'brl';

const PLANS: Record<string, { amount: number; name: string }> = {
  single: { amount: 3490, name: '1 Job Contact' },
  pack5: { amount: 5990, name: '5 Job Contacts Pack' },
  pack10: { amount: 8990, name: '10 Job Contacts Pack' },
  lifetime: { amount: 59900, name: 'Lifetime Unlimited Access' },
};

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const { plan, jobId, lang } = body;
    const pk = plan || 'single';
    const planCfg = PLANS[pk];
    if (!planCfg) return NextResponse.json({ error: 'Invalid plan' }, { status: 400 });

    if (!STRIPE_SECRET) {
      return NextResponse.json({ error: 'Payment system is being configured. Please try again later.' }, { status: 503 });
    }

    const langCode = lang || 'en';
    const baseUrl = BASE_URL.replace(/\/$/, '');

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);

    const res = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Authorization': 'Basic ' + Buffer.from(STRIPE_SECRET + ':').toString('base64'),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        'mode': 'payment',
        'payment_method_types[0]': 'card',
        'line_items[0][price_data][currency]': CURRENCY,
        'line_items[0][price_data][unit_amount]': String(planCfg.amount),
        'line_items[0][price_data][product_data][name]': planCfg.name,
        'line_items[0][quantity]': '1',
        'success_url': `${baseUrl}/${langCode}/jobs?payment=success`,
        'cancel_url': `${baseUrl}/${langCode}/jobs?payment=cancelled`,
        'metadata[plan]': pk,
        'metadata[jobId]': String(jobId || ''),
      }),
    });
    clearTimeout(timeout);

    const session = await res.json();
    if (session.url) return NextResponse.json({ url: session.url, sessionId: session.id });
    return NextResponse.json({ error: session.error?.message || 'Checkout error' }, { status: 400 });
  } catch (err: any) {
    if (err.name === 'AbortError') return NextResponse.json({ error: 'Stripe timeout' }, { status: 504 });
    return NextResponse.json({ error: err.message || 'Error' }, { status: 500 });
  }
}
