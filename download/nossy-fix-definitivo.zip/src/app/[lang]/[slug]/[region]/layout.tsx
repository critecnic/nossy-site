import { Metadata } from "next";
import { LANGUAGES, LANG_SLUGS } from "@/lib/i18n";
import type { Lang } from "@/lib/i18n";

const REGION_META: Record<string, { count: number }> = {
  "europa": { count: 14853 },
  "asia": { count: 10328 },
  "eua": { count: 19046 },
};

export async function generateMetadata({
  params,
}: { params: Promise<{ lang: string; slug: string; region: string }> }): Promise<Metadata> {
  const { lang: langCode, region: rc } = await params;
  const lang = langCode as Lang;
  const meta = REGION_META[rc] || { count: 0 };
  const slug = LANG_SLUGS[lang] || "jobs";
  return {
    title: meta.count.toLocaleString() + "+ Jobs | NOSSY",
    description: "Browse " + meta.count.toLocaleString() + "+ tech jobs on NOSSY.",
    alternates: {
      canonical: "/" + lang + "/" + slug + "/" + rc,
    },
    robots: { index: true, follow: true },
  };
}

export default function RegionLayout({ children }: { children: React.ReactNode }) {
  return children;
}
