import { Metadata } from "next";
import { LANGUAGES, LANG_SLUGS } from "@/lib/i18n";
import type { Lang } from "@/lib/i18n";

const COUNTRY_EN: Record<string, string> = {
  "japao": "Japan", "coreia-do-sul": "South Korea", "singapura": "Singapore",
  "tailandia": "Thailand", "malasia": "Malaysia", "vietna": "Vietnam",
  "filipinas": "Philippines", "paquistao": "Pakistan", "remoto-global": "Remote",
  "india": "India", "china": "China", "indonesia": "Indonesia",
  "hong-kong": "Hong Kong", "taiwan": "Taiwan", "sri-lanka": "Sri Lanka",
  "bangladesh": "Bangladesh", "nepal": "Nepal",
  "united-states": "United States", "united-kingdom": "United Kingdom",
  "germany": "Germany", "france": "France", "spain": "Spain", "italy": "Italy",
  "netherlands": "Netherlands", "poland": "Poland", "ireland": "Ireland",
  "finland": "Finland", "portugal": "Portugal", "switzerland": "Switzerland",
  "denmark": "Denmark", "norway": "Norway", "sweden": "Sweden", "belgium": "Belgium",
  "austria": "Austria", "czech-republic": "Czech Republic", "romania": "Romania",
  "hungary": "Hungary", "greece": "Greece", "bulgaria": "Bulgaria", "croatia": "Croatia",
  "slovakia": "Slovakia", "slovenia": "Slovenia", "estonia": "Estonia",
  "latvia": "Latvia", "lithuania": "Lithuania", "luxembourg": "Luxembourg",
  "malta": "Malta", "cyprus": "Cyprus", "iceland": "Iceland", "serbia": "Serbia",
  "ukraine": "Ukraine", "bosnia-and-herzegovina": "Bosnia and Herzegovina",
  "montenegro": "Montenegro", "moldova": "Moldova", "albania": "Albania",
  "north-macedonia": "North Macedonia", "georgia": "Georgia",
};

export async function generateMetadata({
  params,
}: { params: Promise<{ lang: string; slug: string; region: string; country: string }> }): Promise<Metadata> {
  const { lang: langCode, region: rc, country: cc } = await params;
  const lang = langCode as Lang;
  const countryEn = COUNTRY_EN[cc] || cc;
  const slug = LANG_SLUGS[lang] || "jobs";
  const pageUrl = "/" + lang + "/" + slug + "/" + rc + "/" + cc;
  return {
    title: "Jobs in " + countryEn + " | NOSSY",
    description: "Find tech jobs in " + countryEn + ". Remote, hybrid and on-site positions. Updated daily on NOSSY.",
    alternates: {
      canonical: pageUrl,
    },
    robots: { index: true, follow: true },
  };
}

export default function CountryLayout({ children }: { children: React.ReactNode }) {
  return children;
}
